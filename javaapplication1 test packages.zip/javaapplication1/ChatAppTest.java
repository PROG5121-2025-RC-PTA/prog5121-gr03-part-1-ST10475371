package javaapplication1;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 * Comprehensive test suite for ChatApp functionality
 * @author thaso
 */
public class ChatAppTest {
    
    private final String TEST_JSON_FILE = "testMessages.json";
    
    @BeforeAll
    public static void setUpClass() throws Exception {
        // Global setup if needed
    }

    @AfterAll
    public static void tearDownClass() throws Exception {
        // Global cleanup if needed
    }

    @BeforeEach
    void setUp() {
        // Clean up any existing test files before each test
        cleanUpTestFiles();
    }
    
    @AfterEach
    void tearDown() {
        // Clean up test files after each test
        cleanUpTestFiles();
    }
    
    private void cleanUpTestFiles() {
        File testFile = new File(TEST_JSON_FILE);
        if (testFile.exists()) {
            testFile.delete();
        }
    }
    
    @Test
    @DisplayName("Test Display Sender and Recipient Functionality")
    void testDisplaySenderAndRecipient() {
        // Create sent messages with test data
        List<Message> sentMessages = new ArrayList<>();
        
        Message msg1 = new Message("did you get the cake?", "001", "hash1");
        msg1.setRecipient("0834557896");
        msg1.setTimestamp("2025-06-06 09:00:00");
        
        Message msg2 = new Message("it is dinner time!", "002", "hash2");
        msg2.setRecipient("0838884567");
        msg2.setTimestamp("2025-06-06 09:45:00");
        
        sentMessages.add(msg1);
        sentMessages.add(msg2);
        
        // Test that we can display sender (always "You") and recipient for all sent messages
        for (Message msg : sentMessages) {
            assertNotNull(msg.getRecipient());
            assertTrue(msg.getRecipient().matches("\\d{10}")); // Phone number format
            assertNotNull(msg.getText());
            assertFalse(msg.getText().isEmpty());
        }
        
        // Verify specific recipients
        assertEquals("0834557896", sentMessages.get(0).getRecipient());
        assertEquals("0838884567", sentMessages.get(1).getRecipient());
    }
    
    @Test
    @DisplayName("Test Report Generation")
    void testReportGeneration() {
        // Create comprehensive test data
        List<Message> sentMessages = new ArrayList<>();
        List<Message> disregardedMessages = new ArrayList<>();
        List<Message> storedMessages = new ArrayList<>();
        
        // Populate with all test data
        Message sent1 = new Message("did you get the cake?", "001", "hash1");
        sent1.setRecipient("0834557896");
        sent1.setTimestamp("2025-06-06 09:00:00");
        
        Message sent2 = new Message("it is dinner time!", "004", "hash4");
        sent2.setRecipient("0838884567");
        sent2.setTimestamp("2025-06-06 09:45:00");
        
        Message disregarded = new Message("yohoooo, i am at your gate", "002", "hash2");
        disregarded.setRecipient("0838884567");
        disregarded.setTimestamp("2025-06-06 09:15:00");
        
        Message stored1 = new Message("where are you? You are late! I have asked you to be on time", "003", "hash3");
        stored1.setRecipient("0834484567");
        stored1.setTimestamp("2025-06-06 09:30:00");
        
        Message stored2 = new Message("ok, i am leaving without you", "005", "hash5");
        stored2.setRecipient("0838884567");
        stored2.setTimestamp("2025-06-06 10:00:00");
        
        sentMessages.add(sent1);
        sentMessages.add(sent2);
        disregardedMessages.add(disregarded);
        storedMessages.add(stored1);
        storedMessages.add(stored2);
        
        // Test report statistics
        int totalMessages = sentMessages.size() + disregardedMessages.size() + storedMessages.size();
        assertEquals(5, totalMessages);
        assertEquals(2, sentMessages.size());
        assertEquals(1, disregardedMessages.size());
        assertEquals(2, storedMessages.size());
        
        // Test average message length calculation for sent messages
        int totalChars = sentMessages.stream().mapToInt(msg -> msg.getText().length()).sum();
        double avgLength = (double) totalChars / sentMessages.size();
        
        int expectedTotalChars = "did you get the cake?".length() + "it is dinner time!".length();
        assertEquals(expectedTotalChars, totalChars);
        assertEquals((double) expectedTotalChars / 2, avgLength, 0.1);
    }
    
    @Test
    @DisplayName("Test Message Validation")
    void testMessageValidation() {
        // Test message length validation (should be <= 250 characters)
        String validMessage = "did you get the cake?";
        String longMessage = "a".repeat(251);
        String emptyMessage = "";
        String whitespaceMessage = "   ";
        
        assertTrue(validMessage.length() <= 250);
        assertTrue(longMessage.length() > 250);
        assertTrue(emptyMessage.trim().isEmpty());
        assertTrue(whitespaceMessage.trim().isEmpty());
        
        // Test recipient phone number validation (should be 10 digits)
        String validPhone = "0834557896";
        String invalidPhone1 = "123";
        String invalidPhone2 = "abcd567890";
        
        assertTrue(validPhone.matches("\\d{10}"));
        assertFalse(invalidPhone1.matches("\\d{10}"));
        assertFalse(invalidPhone2.matches("\\d{10}"));
    }
    
    @Test
    @DisplayName("Test Random ID Generation")
    void testGenerateRandomId() {
        // Test that random ID is generated with correct length
        String id1 = ChatApp.generateRandomId();
        String id2 = ChatApp.generateRandomId();
        
        assertNotNull(id1);
        assertNotNull(id2);
        assertEquals(10, id1.length());
        assertEquals(10, id2.length());
        
        // Test that IDs are numeric
        assertTrue(id1.matches("\\d{10}"));
        assertTrue(id2.matches("\\d{10}"));
        
        // Test that different calls generate different IDs (highly probable)
        assertNotEquals(id1, id2);
    }
    
    @Test
    @DisplayName("Test Message Hash Generation")
    void testGenerateMessageHash() {
        // Test hash generation with multiple words
        String id = "1234567890";
        String text = "Hello World";
        int messageNumber = 1;
        
        String expectedHash = "12:1:HELLOWORLD";
        String actualHash = ChatApp.generateMessageHash(id, text, messageNumber);
        
        assertEquals(expectedHash, actualHash);
        
        // Test with single word
        String singleWordText = "Hello";
        String expectedSingleHash = "12:1:HELLOHELLO";
        String actualSingleHash = ChatApp.generateMessageHash(id, singleWordText, messageNumber);
        
        assertEquals(expectedSingleHash, actualSingleHash);
        
        // Test with empty text
        String emptyText = "";
        String expectedEmptyHash = "12:1:";
        String actualEmptyHash = ChatApp.generateMessageHash(id, emptyText, messageNumber);
        
        assertEquals(expectedEmptyHash, actualEmptyHash);
        
        // Test with different message numbers
        String expectedHash2 = "12:5:HELLOWORLD";
        String actualHash2 = ChatApp.generateMessageHash(id, text, 5);
        
        assertEquals(expectedHash2, actualHash2);
    }
    
    @Test
    @DisplayName("Test Message Hash Generation Edge Cases")
    void testGenerateMessageHashEdgeCases() {
        String id = "9876543210";
        
        // Test with extra spaces
        String textWithSpaces = "  Hello   World  ";
        String expectedHash = "98:1:HELLOWORLD";
        String actualHash = ChatApp.generateMessageHash(id, textWithSpaces, 1);
        
        assertEquals(expectedHash, actualHash);
        
        // Test with special characters in words
        String textWithSpecial = "Hello! World?";
        String expectedSpecialHash = "98:1:HELLO!WORLD?";
        String actualSpecialHash = ChatApp.generateMessageHash(id, textWithSpecial, 1);
        
        assertEquals(expectedSpecialHash, actualSpecialHash);
    }
    
    @Test
    @DisplayName("Test Save Messages to JSON")
    void testSaveMessagesToJson() throws IOException {
        // Create test messages using the provided test data
        List<Message> testMessages = new ArrayList<>();
        
        // Test 3: stored message
        Message msg1 = new Message("where are you? You are late! I have asked you to be on time", 
                                  "1234567890", "12:3:WHERETIME");
        msg1.setRecipient("0834484567");
        msg1.setTimestamp("2025-06-06 10:30:00");
        
        // Test 5: stored message
        Message msg2 = new Message("ok, i am leaving without you", 
                                  "0987654321", "09:5:OKYOU");
        msg2.setRecipient("0838884567");
        msg2.setTimestamp("2025-06-06 10:35:00");
        
        testMessages.add(msg1);
        testMessages.add(msg2);
        
        // Save messages to JSON for testing
        saveMessagesToJsonForTesting(testMessages, TEST_JSON_FILE);
        
        // Verify file was created
        File testFile = new File(TEST_JSON_FILE);
        assertTrue(testFile.exists());
        assertTrue(testFile.length() > 0);
    }
    
    @Test
    @DisplayName("Test Message Arrays Population with Test Data")
    void testMessageArraysPopulation() {
        // Create test data based on provided specifications
        List<Message> sentMessages = new ArrayList<>();
        List<Message> disregardedMessages = new ArrayList<>();
        List<Message> storedMessages = new ArrayList<>();
        List<String> messageHashes = new ArrayList<>();
        List<String> messageIds = new ArrayList<>();
        
        // Test 1: sent message
        String id1 = "1234567801";
        String hash1 = ChatApp.generateMessageHash(id1, "did you get the cake?", 1);
        Message sent1 = new Message("did you get the cake?", id1, hash1);
        sent1.setRecipient("0834557896");
        sent1.setTimestamp("2025-06-06 09:00:00");
        sentMessages.add(sent1);
        messageHashes.add(hash1);
        messageIds.add(id1);
        
        // Test 2: disregarded message
        String id2 = "1234567802";
        String hash2 = ChatApp.generateMessageHash(id2, "yohoooo, i am at your gate", 2);
        Message disregarded1 = new Message("yohoooo, i am at your gate", id2, hash2);
        disregarded1.setRecipient("0838884567");
        disregarded1.setTimestamp("2025-06-06 09:15:00");
        disregardedMessages.add(disregarded1);
        
        // Test 3: stored message
        String id3 = "1234567803";
        String hash3 = ChatApp.generateMessageHash(id3, "where are you? You are late! I have asked you to be on time", 3);
        Message stored1 = new Message("where are you? You are late! I have asked you to be on time", id3, hash3);
        stored1.setRecipient("0834484567");
        stored1.setTimestamp("2025-06-06 09:30:00");
        storedMessages.add(stored1);
        
        // Test 4: sent message
        String id4 = "1234567804";
        String hash4 = ChatApp.generateMessageHash(id4, "it is dinner time!", 4);
        Message sent2 = new Message("it is dinner time!", id4, hash4);
        sent2.setRecipient("0838884567");
        sent2.setTimestamp("2025-06-06 09:45:00");
        sentMessages.add(sent2);
        messageHashes.add(hash4);
        messageIds.add(id4);
        
        // Test 5: stored message
        String id5 = "1234567805";
        String hash5 = ChatApp.generateMessageHash(id5, "ok, i am leaving without you", 5);
        Message stored2 = new Message("ok, i am leaving without you", id5, hash5);
        stored2.setRecipient("0838884567");
        stored2.setTimestamp("2025-06-06 10:00:00");
        storedMessages.add(stored2);
        
        // Verify arrays are populated correctly
        assertEquals(2, sentMessages.size());
        assertEquals(1, disregardedMessages.size());
        assertEquals(2, storedMessages.size());
        assertEquals(2, messageHashes.size());
        assertEquals(2, messageIds.size());
        
        // Verify sent messages content
        assertEquals("did you get the cake?", sentMessages.get(0).getText());
        assertEquals("0834557896", sentMessages.get(0).getRecipient());
        assertEquals("it is dinner time!", sentMessages.get(1).getText());
        assertEquals("0838884567", sentMessages.get(1).getRecipient());
        
        // Verify disregarded message content
        assertEquals("yohoooo, i am at your gate", disregardedMessages.get(0).getText());
        assertEquals("0838884567", disregardedMessages.get(0).getRecipient());
        
        // Verify stored messages content
        assertEquals("where are you? You are late! I have asked you to be on time", storedMessages.get(0).getText());
        assertEquals("0834484567", storedMessages.get(0).getRecipient());
        assertEquals("ok, i am leaving without you", storedMessages.get(1).getText());
        assertEquals("0838884567", storedMessages.get(1).getRecipient());
    }
    
    @Test
    @DisplayName("Test Find Longest Message")
    void testFindLongestMessage() {
        // Create test messages with different lengths
        List<Message> messages = new ArrayList<>();
        
        Message short1 = new Message("did you get the cake?", "001", "hash1");
        short1.setRecipient("0834557896");
        
        Message long1 = new Message("where are you? You are late! I have asked you to be on time", "002", "hash2");
        long1.setRecipient("0834484567");
        
        Message short2 = new Message("it is dinner time!", "003", "hash3");
        short2.setRecipient("0838884567");
        
        messages.add(short1);
        messages.add(long1);
        messages.add(short2);
        
        // Find longest message
        Message longest = messages.get(0);
        for (Message msg : messages) {
            if (msg.getText().length() > longest.getText().length()) {
                longest = msg;
            }
        }
        
        assertEquals("where are you? You are late! I have asked you to be on time", longest.getText());
        assertEquals("0834484567", longest.getRecipient());
        assertEquals(62, longest.getText().length());
    }
    
    @Test
    @DisplayName("Test Search Message by ID")
    void testSearchMessageById() {
        // Create test messages
        List<Message> sentMessages = new ArrayList<>();
        
        String searchId = "1234567801";
        Message msg1 = new Message("did you get the cake?", searchId, "hash1");
        msg1.setRecipient("0834557896");
        
        Message msg2 = new Message("it is dinner time!", "1234567804", "hash2");
        msg2.setRecipient("0838884567");
        
        sentMessages.add(msg1);
        sentMessages.add(msg2);
        
        // Search for message by ID
        Message found = null;
        for (Message msg : sentMessages) {
            if (msg.getId().equals(searchId)) {
                found = msg;
                break;
            }
        }
        
        assertNotNull(found);
        assertEquals("did you get the cake?", found.getText());
        assertEquals("0834557896", found.getRecipient());
        assertEquals(searchId, found.getId());
    }
    
    @Test
    @DisplayName("Test Delete Message by Hash")
    void testDeleteMessageByHash() {
        // Create test messages
        List<Message> sentMessages = new ArrayList<>();
        List<String> messageHashes = new ArrayList<>();
        List<String> messageIds = new ArrayList<>();
        
        String deleteHash = "hash1";
        Message msg1 = new Message("did you get the cake?", "001", deleteHash);
        msg1.setRecipient("0834557896");
        
        Message msg2 = new Message("it is dinner time!", "002", "hash2");
        msg2.setRecipient("0838884567");
        
        sentMessages.add(msg1);
        sentMessages.add(msg2);
        messageHashes.add(deleteHash);
        messageHashes.add("hash2");
        messageIds.add("001");
        messageIds.add("002");
        
        // Find and delete message by hash
        Message messageToDelete = null;
        for (Message msg : sentMessages) {
            if (msg.getHash().equals(deleteHash)) {
                messageToDelete = msg;
                break;
            }
        }
        
        assertNotNull(messageToDelete);
        
        // Simulate deletion
        sentMessages.remove(messageToDelete);
        messageHashes.remove(messageToDelete.getHash());
        messageIds.remove(messageToDelete.getId());
        
        // Verify deletion
        assertEquals(1, sentMessages.size());
        assertEquals(1, messageHashes.size());
        assertEquals(1, messageIds.size());
        assertEquals("it is dinner time!", sentMessages.get(0).getText());
        assertFalse(messageHashes.contains(deleteHash));
        assertFalse(messageIds.contains("001"));
    }
    
    @Test
    @DisplayName("Test Generate Hash with Test Data")
    void testGenerateHashWithTestData() {
        // Test hash generation with actual test data
        String id = "1234567801";
        
        // Test 1: "did you get the cake?"
        String hash1 = ChatApp.generateMessageHash(id, "did you get the cake?", 1);
        assertEquals("12:1:DIDCAKE?", hash1);
        
        // Test 2: "yohoooo, i am at your gate"
        String hash2 = ChatApp.generateMessageHash(id, "yohoooo, i am at your gate", 2);
        assertEquals("12:2:YOHOOOGATE", hash2);
        
        // Test 3: "where are you? You are late! I have asked you to be on time"
        String hash3 = ChatApp.generateMessageHash(id, "where are you? You are late! I have asked you to be on time", 3);
        assertEquals("12:3:WHERETIME", hash3);
        
        // Test 4: "it is dinner time!"
        String hash4 = ChatApp.generateMessageHash(id, "it is dinner time!", 4);
        assertEquals("12:4:ITTIME!", hash4);
        
        // Test 5: "ok, i am leaving without you"
        String hash5 = ChatApp.generateMessageHash(id, "ok, i am leaving without you", 5);
        assertEquals("12:5:OKYOU", hash5);
    }

    @Test
    @DisplayName("Test Main Method")
    public void testMain() {
        // Test that main method runs without throwing exceptions
        String[] args = {};
        
        // This test assumes ChatApp.main() doesn't cause system exit
        // In a real scenario, you might want to test specific functionality
        // rather than the main method directly
        assertDoesNotThrow(() -> {
            // ChatApp.main(args); // Uncomment if you want to test main method
        });
    }
    
    // Helper method for testing JSON functionality
    private void saveMessagesToJsonForTesting(List<Message> messages, String filename) throws IOException {
        JSONArray jsonArray = new JSONArray();

        for (Message msg : messages) {
            JSONObject obj = new JSONObject();
            obj.put("text", msg.getText());
            obj.put("id", msg.getId());
            obj.put("hash", msg.getHash());
            obj.put("recipient", msg.getRecipient());
            obj.put("timestamp", msg.getTimestamp());
            jsonArray.add(obj);
        }

        try (FileWriter file = new FileWriter(filename)) {
            file.write(jsonArray.toJSONString());
            file.flush();
        }
    }
}