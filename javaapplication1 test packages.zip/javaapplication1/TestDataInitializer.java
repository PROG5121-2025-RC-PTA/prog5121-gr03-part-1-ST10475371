/*
 * Test Data Initializer - Populates arrays with the specified test data
 */
package javaapplication1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author thaso
 */
public class TestDataInitializer {
    
    /**
     * Initializes all arrays with the specified test data
     * @param sentMessages - List to populate with sent messages
     * @param disregardedMessages - List to populate with disregarded messages
     * @param storedMessages - List to populate with stored messages
     * @param messageHashes - List to populate with message hashes
     * @param messageIds - List to populate with message IDs
     */
    public static void initializeTestData(List<Message> sentMessages,
                                        List<Message> disregardedMessages,
                                        List<Message> storedMessages,
                                        List<String> messageHashes,
                                        List<String> messageIds) {
        
        // Clear existing data
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        messageHashes.clear();
        messageIds.clear();
        
        String baseTime = "2025-06-06 ";
        
        // Test 1: recipient: 0834557896, message: "did you get the cake?", flag: sent
        String id1 = "1234567801";
        String hash1 = ChatApp.generateMessageHash(id1, "did you get the cake?", 1);
        Message test1 = new Message("did you get the cake?", id1, hash1);
        test1.setRecipient("0834557896");
        test1.setTimestamp(baseTime + "09:00:00");
        sentMessages.add(test1);
        messageHashes.add(hash1);
        messageIds.add(id1);
        
        // Test 2: recipient: 0838884567, message: "yohoooo, i am at your gate", flag: disregard
        String id2 = "1234567802";
        String hash2 = ChatApp.generateMessageHash(id2, "yohoooo, i am at your gate", 2);
        Message test2 = new Message("yohoooo, i am at your gate", id2, hash2);
        test2.setRecipient("0838884567");
        test2.setTimestamp(baseTime + "09:15:00");
        disregardedMessages.add(test2);
        
        // Test 3: recipient: 0834484567, message: "where are you? You are late! I have asked you to be on time", flag: stored
        String id3 = "1234567803";
        String hash3 = ChatApp.generateMessageHash(id3, "where are you? You are late! I have asked you to be on time", 3);
        Message test3 = new Message("where are you? You are late! I have asked you to be on time", id3, hash3);
        test3.setRecipient("0834484567");
        test3.setTimestamp(baseTime + "09:30:00");
        storedMessages.add(test3);
        
        // Test 4: recipient: 0838884567, message: "it is dinner time!", flag: sent
        String id4 = "1234567804";
        String hash4 = ChatApp.generateMessageHash(id4, "it is dinner time!", 4);
        Message test4 = new Message("it is dinner time!", id4, hash4);
        test4.setRecipient("0838884567");
        test4.setTimestamp(baseTime + "09:45:00");
        sentMessages.add(test4);
        messageHashes.add(hash4);
        messageIds.add(id4);
        
        // Test 5: recipient: 0838884567, message: "ok, i am leaving without you", flag: stored
        String id5 = "1234567805";
        String hash5 = ChatApp.generateMessageHash(id5, "ok, i am leaving without you", 5);
        Message test5 = new Message("ok, i am leaving without you", id5, hash5);
        test5.setRecipient("0838884567");
        test5.setTimestamp(baseTime + "10:00:00");
        storedMessages.add(test5);
    }
    
    /**
     * Displays a summary of all test data for verification
     */
    public static void displayTestDataSummary(List<Message> sentMessages,
                                            List<Message> disregardedMessages,
                                            List<Message> storedMessages,
                                            List<String> messageHashes,
                                            List<String> messageIds) {
        
        System.out.println("=== TEST DATA SUMMARY ===");
        System.out.println("Total Messages: " + (sentMessages.size() + disregardedMessages.size() + storedMessages.size()));
        System.out.println("Sent Messages: " + sentMessages.size());
        System.out.println("Disregarded Messages: " + disregardedMessages.size());
        System.out.println("Stored Messages: " + storedMessages.size());
        System.out.println("Message Hashes: " + messageHashes.size());
        System.out.println("Message IDs: " + messageIds.size());
        
        System.out.println("\n=== SENT MESSAGES ===");
        for (int i = 0; i < sentMessages.size(); i++) {
            Message msg = sentMessages.get(i);
            System.out.println("Sent #" + (i+1) + ":");
            System.out.println("  Recipient: " + msg.getRecipient());
            System.out.println("  Message: " + msg.getText());
            System.out.println("  ID: " + msg.getId());
            System.out.println("  Hash: " + msg.getHash());
            System.out.println("  Time: " + msg.getTimestamp());
        }
        
        System.out.println("\n=== DISREGARDED MESSAGES ===");
        for (int i = 0; i < disregardedMessages.size(); i++) {
            Message msg = disregardedMessages.get(i);
            System.out.println("Disregarded #" + (i+1) + ":");
            System.out.println("  Recipient: " + msg.getRecipient());
            System.out.println("  Message: " + msg.getText());
            System.out.println("  ID: " + msg.getId());
            System.out.println("  Hash: " + msg.getHash());
            System.out.println("  Time: " + msg.getTimestamp());
        }
        
        System.out.println("\n=== STORED MESSAGES ===");
        for (int i = 0; i < storedMessages.size(); i++) {
            Message msg = storedMessages.get(i);
            System.out.println("Stored #" + (i+1) + ":");
            System.out.println("  Recipient: " + msg.getRecipient());
            System.out.println("  Message: " + msg.getText());
            System.out.println("  ID: " + msg.getId());
            System.out.println("  Hash: " + msg.getHash());
            System.out.println("  Time: " + msg.getTimestamp());
        }
        
        System.out.println("\n=== MESSAGE HASHES ===");
        for (int i = 0; i < messageHashes.size(); i++) {
            System.out.println("Hash #" + (i+1) + ": " + messageHashes.get(i));
        }
        
        System.out.println("\n=== MESSAGE IDS ===");
        for (int i = 0; i < messageIds.size(); i++) {
            System.out.println("ID #" + (i+1) + ": " + messageIds.get(i));
        }
    }
    
    /**
     * Validates that test data matches expected values
     */
    public static boolean validateTestData(List<Message> sentMessages,
                                         List<Message> disregardedMessages,
                                         List<Message> storedMessages,
                                         List<String> messageHashes,
                                         List<String> messageIds) {
        
        // Check counts
        if (sentMessages.size() != 2) return false;
        if (disregardedMessages.size() != 1) return false;
        if (storedMessages.size() != 2) return false;
        if (messageHashes.size() != 2) return false; // Only sent messages have hashes in arrays
        if (messageIds.size() != 2) return false; // Only sent messages have IDs in arrays
        
        // Check sent message 1
        Message sent1 = sentMessages.get(0);
        if (!sent1.getText().equals("did you get the cake?")) return false;
        if (!sent1.getRecipient().equals("0834557896")) return false;
        if (!sent1.getId().equals("1234567801")) return false;
        
        // Check sent message 2
        Message sent2 = sentMessages.get(1);
        if (!sent2.getText().equals("it is dinner time!")) return false;
        if (!sent2.getRecipient().equals("0838884567")) return false;
        if (!sent2.getId().equals("1234567804")) return false;
        
        // Check disregarded message
        Message disregarded = disregardedMessages.get(0);
        if (!disregarded.getText().equals("yohoooo, i am at your gate")) return false;
        if (!disregarded.getRecipient().equals("0838884567")) return false;
        if (!disregarded.getId().equals("1234567802")) return false;
        
        // Check stored message 1
        Message stored1 = storedMessages.get(0);
        if (!stored1.getText().equals("where are you? You are late! I have asked you to be on time")) return false;
        if (!stored1.getRecipient().equals("0834484567")) return false;
        if (!stored1.getId().equals("1234567803")) return false;
        
        // Check stored message 2
        Message stored2 = storedMessages.get(1);
        if (!stored2.getText().equals("ok, i am leaving without you")) return false;
        if (!stored2.getRecipient().equals("0838884567")) return false;
        if (!stored2.getId().equals("1234567805")) return false;
        
        return true;
    }
    
    /**
     * Finds the longest message across all message arrays
     */
    public static Message findLongestMessage(List<Message> sentMessages,
                                           List<Message> disregardedMessages,
                                           List<Message> storedMessages) {
        
        List<Message> allMessages = new ArrayList<>();
        allMessages.addAll(sentMessages);
        allMessages.addAll(disregardedMessages);
        allMessages.addAll(storedMessages);
        
        if (allMessages.isEmpty()) return null;
        
        Message longest = allMessages.get(0);
        for (Message msg : allMessages) {
            if (msg.getText().length() > longest.getText().length()) {
                longest = msg;
            }
        }
        
        return longest;
    }
}