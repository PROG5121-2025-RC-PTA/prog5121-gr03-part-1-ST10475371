/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import java.io.FileReader;
import java.io.File;
import java.util.concurrent.CountDownLatch;

/**
 *
 * @author thaso
 */
public class ChatApp {

    // Arrays to store different types of messages and data
    private static List<Message> sentMessages = new ArrayList<>();
    private static List<Message> disregardedMessages = new ArrayList<>();
    private static List<Message> storedMessages = new ArrayList<>();
    private static List<String> messageHashes = new ArrayList<>();
    private static List<String> messageIds = new ArrayList<>();
    
    public static void main(String args[]) {
        
        // Load stored messages from JSON file at startup
        loadStoredMessagesFromJson();
        
        // Welcome message
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat!");

        // Main Menu
        while (true) {
            String[] mainOptions = {"Send Message", "Show Recent Messages", "Message Operations", "Reports", "Quit"};
            int mainChoice = JOptionPane.showOptionDialog(null, 
                "What would you like to do?",
                "QuickChat Menu", 
                JOptionPane.DEFAULT_OPTION, 
                JOptionPane.INFORMATION_MESSAGE,
                null, mainOptions, mainOptions[0]);
            
            switch (mainChoice) {
                case 0 -> sendMessages(); // Send Message
                case 1 -> showRecentMessages(); // Show Recent Messages
                case 2 -> messageOperations(); // Message Operations
                case 3 -> showReports(); // Reports
                case 4 -> quitToLogin(); // Quit
                default -> quitToLogin(); // Closes window
            }
        }
    }

    private static void sendMessages() {
        String input = JOptionPane.showInputDialog(null, "How many messages do you want to enter?");
        if (input == null) return;

        try {
            int messageCount = Integer.parseInt(input);
            if (messageCount <= 0) {
                JOptionPane.showMessageDialog(null, "Please enter a number greater than zero.");
                return;
            }
            
            for (int i = 0; i < messageCount; i++) {
                String messageText = JOptionPane.showInputDialog(null, "Enter message " + (i + 1) + ":");
                if (messageText == null) {
                    JOptionPane.showMessageDialog(null, "Message entry cancelled.");
                    continue;
                }
                
                messageText = messageText.trim();
                if (messageText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Message cannot be empty.");
                    i--; // repeat current message
                    continue;
                }

                if (messageText.length() > 250) {
                    JOptionPane.showMessageDialog(null, "Please enter a message of less than 250 characters.");
                    i--;
                    continue;
                }
                
                String messageId = generateRandomId();
                String hash = generateMessageHash(messageId, messageText, i+1);

                String[] options = {"Send Message", "Discard Message", "Store Message to Send Later"};
                int choice = JOptionPane.showOptionDialog(null, "What would you like to do with this message?",
                        "Choose Action", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                        null, options, options[0]);
                
                switch (choice) {
                    case 0 -> { // Send
                        String recipient = sendMessage(messageText, messageId, hash);
                        if (recipient != null) {
                            Message sentMsg = new Message(messageText, messageId, hash);
                            sentMsg.setRecipient(recipient);
                            sentMsg.setTimestamp(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
                            sentMessages.add(sentMsg);
                            messageHashes.add(hash);
                            messageIds.add(messageId);
                        }
                    }
                    case 1 -> { // Discard
                        Message discardedMsg = new Message(messageText, messageId, hash);
                        discardedMsg.setTimestamp(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
                        disregardedMessages.add(discardedMsg);
                        JOptionPane.showMessageDialog(null, "Message discarded.");
                    }
                    case 2 -> { // Store
                        Message storeMsg = new Message(messageText, messageId, hash);
                        storeMsg.setTimestamp(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
                        storedMessages.add(storeMsg);
                        JOptionPane.showMessageDialog(null, "Message stored for later.");
                    }
                    default -> JOptionPane.showMessageDialog(null, "Action cancelled.");
                }
            }
 
            if (!storedMessages.isEmpty()) {
                saveMessagesToJson(storedMessages);
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid number. Please enter a valid integer.");
        }
    }

    private static String sendMessage(String messageText, String messageId, String hash) {
        // Ask user to enter phone number
        String phoneNumber = "";
        while (phoneNumber.isEmpty()) {
            phoneNumber = JOptionPane.showInputDialog(null, "Enter recipient's phone number:");
            if (phoneNumber == null) {
                JOptionPane.showMessageDialog(null, "Message sending cancelled.");
                return null;
            }
            phoneNumber = phoneNumber.trim();
            if (phoneNumber.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Phone number cannot be empty. Please enter a valid phone number.");
            }
        }
        String timestamp = new SimpleDateFormat("HH:mm").format(new Date());
        
        JOptionPane.showMessageDialog(null,
            "Sent to: " + phoneNumber +
            "\nTime: " + timestamp +
            "\nMessage: " + messageText +
            "\nStatus: ✔ Sent"
        );

        CountDownLatch latch = new CountDownLatch(1);

        new Thread(() -> {
            try {
                Thread.sleep(500); // Delivered after 0.5s
                javax.swing.SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(null, "✔✔ Delivered");
                });
                Thread.sleep(1000); // Read after 1s
                javax.swing.SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(null, "<html><font color='blue'>✔✔ Read</font></html>");
                });
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                latch.countDown(); //continue
            }
        }).start();

        try {
            latch.await(); // wait for status thread to complete before next message
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        return phoneNumber;
    }

    private static void showRecentMessages() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No recent messages to display.");
            return;
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append("Recent Messages:\n\n");
        
        int count = Math.min(5, sentMessages.size());
        for (int i = sentMessages.size() - count; i < sentMessages.size(); i++) {
            Message msg = sentMessages.get(i);
            sb.append("To: ").append(msg.getRecipient()).append("\n");
            sb.append("Message: ").append(msg.getText()).append("\n");
            sb.append("Time: ").append(msg.getTimestamp()).append("\n\n");
        }
        
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void messageOperations() {
        String[] options = {"Display Sent Messages", "Display Longest Message", "Search by Message ID", 
                           "Delete Message by Hash", "Back to Main Menu"};
        
        int choice = JOptionPane.showOptionDialog(null, 
            "Choose an operation:",
            "Message Operations", 
            JOptionPane.DEFAULT_OPTION, 
            JOptionPane.INFORMATION_MESSAGE,
            null, options, options[0]);
        
        switch (choice) {
            case 0 -> displaySentMessages();
            case 1 -> displayLongestMessage();
            case 2 -> searchByMessageId();
            case 3 -> deleteMessageByHash();
            case 4 -> { /* Back to main menu */ }
            default -> { /* Handle window close */ }
        }
    }

    private static void displaySentMessages() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to display.");
            return;
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append("All Sent Messages:\n\n");
        
        for (int i = 0; i < sentMessages.size(); i++) {
            Message msg = sentMessages.get(i);
            sb.append("Message ").append(i + 1).append(":\n");
            sb.append("Sender: You\n");
            sb.append("Recipient: ").append(msg.getRecipient()).append("\n");
            sb.append("Message: ").append(msg.getText()).append("\n");
            sb.append("ID: ").append(msg.getId()).append("\n");
            sb.append("Hash: ").append(msg.getHash()).append("\n");
            sb.append("Time: ").append(msg.getTimestamp()).append("\n\n");
        }
        
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void displayLongestMessage() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to analyze.");
            return;
        }
        
        Message longestMessage = sentMessages.get(0);
        for (Message msg : sentMessages) {
            if (msg.getText().length() > longestMessage.getText().length()) {
                longestMessage = msg;
            }
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append("Longest Sent Message:\n\n");
        sb.append("Recipient: ").append(longestMessage.getRecipient()).append("\n");
        sb.append("Message: ").append(longestMessage.getText()).append("\n");
        sb.append("Length: ").append(longestMessage.getText().length()).append(" characters\n");
        sb.append("ID: ").append(longestMessage.getId()).append("\n");
        sb.append("Hash: ").append(longestMessage.getHash()).append("\n");
        sb.append("Time: ").append(longestMessage.getTimestamp()).append("\n");
        
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void searchByMessageId() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to search.");
            return;
        }
        
        String searchId = JOptionPane.showInputDialog(null, "Enter Message ID to search:");
        if (searchId == null || searchId.trim().isEmpty()) {
            return;
        }
        
        Message foundMessage = null;
        for (Message msg : sentMessages) {
            if (msg.getId().equals(searchId.trim())) {
                foundMessage = msg;
                break;
            }
        }
        
        if (foundMessage != null) {
            StringBuilder sb = new StringBuilder();
            sb.append("Message Found:\n\n");
            sb.append("Recipient: ").append(foundMessage.getRecipient()).append("\n");
            sb.append("Message: ").append(foundMessage.getText()).append("\n");
            sb.append("ID: ").append(foundMessage.getId()).append("\n");
            sb.append("Hash: ").append(foundMessage.getHash()).append("\n");
            sb.append("Time: ").append(foundMessage.getTimestamp()).append("\n");
            
            JOptionPane.showMessageDialog(null, sb.toString());
        } else {
            JOptionPane.showMessageDialog(null, "No message found with ID: " + searchId);
        }
    }

    private static void deleteMessageByHash() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to delete.");
            return;
        }
        
        String searchHash = JOptionPane.showInputDialog(null, "Enter Message Hash to delete:");
        if (searchHash == null || searchHash.trim().isEmpty()) {
            return;
        }
        
        Message messageToDelete = null;
        for (Message msg : sentMessages) {
            if (msg.getHash().equals(searchHash.trim())) {
                messageToDelete = msg;
                break;
            }
        }
        
        if (messageToDelete != null) {
            int confirm = JOptionPane.showConfirmDialog(null, 
                "Are you sure you want to delete this message?\n\n" +
                "Recipient: " + messageToDelete.getRecipient() + "\n" +
                "Message: " + messageToDelete.getText(),
                "Confirm Deletion", 
                JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                sentMessages.remove(messageToDelete);
                messageHashes.remove(messageToDelete.getHash());
                messageIds.remove(messageToDelete.getId());
                JOptionPane.showMessageDialog(null, "Message deleted successfully.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "No message found with hash: " + searchHash);
        }
    }

    private static void showReports() {
        String[] options = {"Full Details Report", "Summary Statistics", "Back to Main Menu"};
        
        int choice = JOptionPane.showOptionDialog(null, 
            "Choose a report:",
            "Reports", 
            JOptionPane.DEFAULT_OPTION, 
            JOptionPane.INFORMATION_MESSAGE,
            null, options, options[0]);
        
        switch (choice) {
            case 0 -> showFullDetailsReport();
            case 1 -> showSummaryStatistics();
            case 2 -> { /* Back to main menu */ }
            default -> { /* Closes Window */ }
        }
    }

    private static void showFullDetailsReport() { // Full Details Report
        StringBuilder sb = new StringBuilder();
        sb.append("FULL DETAILS REPORT\n");
        sb.append("==================\n\n");
        
        sb.append("SENT MESSAGES (").append(sentMessages.size()).append("):\n");
        sb.append("--------------------\n");
        for (int i = 0; i < sentMessages.size(); i++) {
            Message msg = sentMessages.get(i);
            sb.append("Message #").append(i + 1).append(":\n");
            sb.append("  Sender: You\n");
            sb.append("  Recipient: ").append(msg.getRecipient()).append("\n");
            sb.append("  Message: ").append(msg.getText()).append("\n");
            sb.append("  ID: ").append(msg.getId()).append("\n");
            sb.append("  Hash: ").append(msg.getHash()).append("\n");
            sb.append("  Timestamp: ").append(msg.getTimestamp()).append("\n");
            sb.append("  Length: ").append(msg.getText().length()).append(" characters\n\n");
        }
        
        sb.append("DISREGARDED MESSAGES (").append(disregardedMessages.size()).append("):\n");
        sb.append("------------------------\n");
        for (int i = 0; i < disregardedMessages.size(); i++) {
            Message msg = disregardedMessages.get(i);
            sb.append("Message #").append(i + 1).append(":\n");
            sb.append("  Message: ").append(msg.getText()).append("\n");
            sb.append("  ID: ").append(msg.getId()).append("\n");
            sb.append("  Hash: ").append(msg.getHash()).append("\n");
            sb.append("  Timestamp: ").append(msg.getTimestamp()).append("\n\n");
        }
        
        sb.append("STORED MESSAGES (").append(storedMessages.size()).append("):\n");
        sb.append("-------------------\n");
        for (int i = 0; i < storedMessages.size(); i++) {
            Message msg = storedMessages.get(i);
            sb.append("Message #").append(i + 1).append(":\n");
            sb.append("  Message: ").append(msg.getText()).append("\n");
            sb.append("  ID: ").append(msg.getId()).append("\n");
            sb.append("  Hash: ").append(msg.getHash()).append("\n");
            sb.append("  Timestamp: ").append(msg.getTimestamp()).append("\n\n");
        }
        
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void showSummaryStatistics() { // Summary Stats
        StringBuilder sb = new StringBuilder();
        sb.append("SUMMARY STATISTICS\n");
        sb.append("==================\n\n");
        
        sb.append("Total Messages Created: ").append(sentMessages.size() + disregardedMessages.size() + storedMessages.size()).append("\n");
        sb.append("Sent Messages: ").append(sentMessages.size()).append("\n");
        sb.append("Disregarded Messages: ").append(disregardedMessages.size()).append("\n");
        sb.append("Stored Messages: ").append(storedMessages.size()).append("\n\n");
        
        if (!sentMessages.isEmpty()) {
            int totalChars = sentMessages.stream().mapToInt(msg -> msg.getText().length()).sum();
            double avgLength = (double) totalChars / sentMessages.size();
            sb.append("Average Message Length: ").append(String.format("%.1f", avgLength)).append(" characters\n");
            
            Message longest = sentMessages.stream().max((a, b) -> Integer.compare(a.getText().length(), b.getText().length())).orElse(null);
            Message shortest = sentMessages.stream().min((a, b) -> Integer.compare(a.getText().length(), b.getText().length())).orElse(null);
            
            if (longest != null) {
                sb.append("Longest Message: ").append(longest.getText().length()).append(" characters\n");
            }
            if (shortest != null) {
                sb.append("Shortest Message: ").append(shortest.getText().length()).append(" characters\n");
            }
        }
        
        sb.append("\nUnique Message IDs: ").append(messageIds.size()).append("\n");
        sb.append("Unique Message Hashes: ").append(messageHashes.size()).append("\n");
        
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void quitToLogin() { // Save all data before quitting
        if (!storedMessages.isEmpty()) {
            saveMessagesToJson(storedMessages);
        }
        
        // Back to LoginPage
        try {
            new LoginPage().setVisible(true);
            System.exit(0); // Close current application
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Goodbye!");
            System.exit(0);
        }
    }

    public static String generateRandomId() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }

    public static String generateMessageHash(String id, String text, int messageNumber) {
        String[] words = text.trim().split("\\s+");
        String firstTwoDigits = id.substring(0, 2);
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        return firstTwoDigits + ":" + messageNumber + ":" + (firstWord + lastWord).toUpperCase();
    }
    
    public static void saveMessagesToJson(List<Message> messages) {
        JSONArray jsonArray = new JSONArray();
        
        for (Message msg : messages) {
            JSONObject obj = new JSONObject();
            obj.put("text", msg.getText());
            obj.put("id", msg.getId());
            obj.put("hash", msg.getHash());
            obj.put("recipient", msg.getRecipient());
            obj.put("timestamp", msg.getTimestamp());
            jsonArray.add(obj);
        }

        try (FileWriter file = new FileWriter("storedMessages.json")) {
            file.write(jsonArray.toJSONString());
            file.flush();
            JOptionPane.showMessageDialog(null, "Messages saved to storedMessages.json");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving messages: " + e.getMessage());
        }
    }
    
    private static void loadStoredMessagesFromJson() {
        File file = new File("storedMessages.json");
        if (!file.exists()) {
            return;
        }
        
        try (FileReader reader = new FileReader("storedMessages.json")) {
            JSONParser parser = new JSONParser();
            JSONArray jsonArray = (JSONArray) parser.parse(reader);
            
            storedMessages.clear();
            
            for (Object obj : jsonArray) {
                JSONObject jsonObj = (JSONObject) obj;
                String text = (String) jsonObj.get("text");
                String id = (String) jsonObj.get("id");
                String hash = (String) jsonObj.get("hash");
                String recipient = (String) jsonObj.get("recipient");
                String timestamp = (String) jsonObj.get("timestamp");
                
                Message msg = new Message(text, id, hash);
                msg.setRecipient(recipient);
                msg.setTimestamp(timestamp);
                storedMessages.add(msg);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error loading stored messages: " + e.getMessage());
        }
    }
}