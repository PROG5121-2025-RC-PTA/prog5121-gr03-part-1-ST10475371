/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.util.concurrent.CountDownLatch;

/**
 *
 * @author thaso
 */
public class ChatApp {

    private static List<Message> sentMessages = new ArrayList<>();
    private static List<Message> storedMessages = new ArrayList<>();
    
    public static void main(String args[]) {
        
        // Welcome message
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat!");

        // Show main menu with 3 options
        while (true) {
            String[] mainOptions = {"Send Message", "Show Recent Messages", "Quit"};
            int mainChoice = JOptionPane.showOptionDialog(null, 
                "What would you like to do?",
                "QuickChat Menu", 
                JOptionPane.DEFAULT_OPTION, 
                JOptionPane.INFORMATION_MESSAGE,
                null, mainOptions, mainOptions[0]);
            
            switch (mainChoice) {
                case 0 -> sendMessages(); // Send Message
                case 1 -> showRecentMessages(); // Show Recent Messages
                case 2 -> quitToLogin(); // Quit
                default -> quitToLogin(); // Handle window close
            }
        }
    }

    private static void sendMessages() {
        String input = JOptionPane.showInputDialog(null, "How many messages do you want to enter?");
        if (input == null) return;

        try {
            int messageCount = Integer.parseInt(input);
            if (messageCount <= 0) {
                JOptionPane.showMessageDialog(null, "Please enter a number greater than zero.");
                return;
            }
            
            for (int i = 0; i < messageCount; i++) {
                String messageText = JOptionPane.showInputDialog(null, "Enter message " + (i + 1) + ":");
                if (messageText == null) {
                    JOptionPane.showMessageDialog(null, "Message entry cancelled.");
                    continue;
                }
                
                messageText = messageText.trim();
                if (messageText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Message cannot be empty.");
                    i--; // repeat current message
                    continue;
                }

                if (messageText.length() > 250) {
                    JOptionPane.showMessageDialog(null, "Please enter a message of less than 250 characters.");
                    i--;
                    continue;
                }
                
                String messageId = generateRandomId();
                String hash = generateMessageHash(messageId, messageText, i+1);

                String[] options = {"Send Message", "Discard Message", "Store Message to Send Later"};
                int choice = JOptionPane.showOptionDialog(null, "What would you like to do with this message?",
                        "Choose Action", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                        null, options, options[0]);
                
                switch (choice) {
                    case 0 -> { // Send
                        sendMessage(messageText, messageId, hash);
                        sentMessages.add(new Message(messageText, messageId, hash));
                    }
                    case 1 -> // Discard
                        JOptionPane.showMessageDialog(null, "Message discarded.");
                    case 2 -> { // Store
                        storedMessages.add(new Message(messageText, messageId, hash));
                        JOptionPane.showMessageDialog(null, "Message stored for later.");
                    }
                    default -> JOptionPane.showMessageDialog(null, "Action cancelled.");
                }
            }
 
            if (!storedMessages.isEmpty()) {
                saveMessagesToJson(storedMessages);
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid number. Please enter a valid integer.");
        }
    }

    private static void sendMessage(String messageText, String messageId, String hash) {
        // Ask user to enter recipient's phone number
        String phoneNumber = "";
        while (phoneNumber.isEmpty()) {
            phoneNumber = JOptionPane.showInputDialog(null, "Enter recipient's phone number:");
            if (phoneNumber == null) {
                JOptionPane.showMessageDialog(null, "Message sending cancelled.");
                return;
            }
            phoneNumber = phoneNumber.trim();
            if (phoneNumber.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Phone number cannot be empty. Please enter a valid phone number.");
            }
        }
        String timestamp = new SimpleDateFormat("HH:mm").format(new Date());
        
        JOptionPane.showMessageDialog(null,
            "Sent to: " + phoneNumber +
            "\nTime: " + timestamp +
            "\nMessage: " + messageText +
            "\nStatus: ✔ Sent"
        );

        CountDownLatch latch = new CountDownLatch(1);

        new Thread(() -> {
            try {
                Thread.sleep(500); // Delivered after 0.5s
                javax.swing.SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(null, "✔✔ Delivered");
                });
                Thread.sleep(1000); // Read after 1s
                javax.swing.SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(null, "<html><font color='blue'>✔✔ Read</font></html>");
                });
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                latch.countDown(); // allow main thread to continue
            }
        }).start();

        try {
            latch.await(); // wait for status thread to complete before next message
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static void showRecentMessages() {
        JOptionPane.showMessageDialog(null, "This feature is coming soon!");
    }

    private static void quitToLogin() {
        // Navigate back to LoginPage
        try {
            new LoginPage().setVisible(true);
            System.exit(0); // Close current application
        } catch (Exception e) {
            // If LoginPage class doesn't exist or there's an error, just exit
            JOptionPane.showMessageDialog(null, "Goodbye!");
            System.exit(0);
        }
    }

    public static String generateRandomId() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }

    public static String generateMessageHash(String id, String text, int messageNumber) {
    String[] words = text.trim().split("\\s+");
    String firstTwoDigits = id.substring(0, 2);
    String firstWord = words.length > 0 ? words[0] : "";
    String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
    return firstTwoDigits + ":" + messageNumber + ":" + (firstWord + lastWord).toUpperCase();
    }
    
    public static void saveMessagesToJson(List<Message> messages) {
        JSONArray jsonArray = new JSONArray();

        for (Message msg : messages) {
            JSONObject obj = new JSONObject();
            obj.put("text", msg.getText());
            obj.put("id", msg.getId());
            obj.put("hash", msg.getHash());
            jsonArray.add(obj);
        }

        try (FileWriter file = new FileWriter("storedMessages.json")) {
            file.write(jsonArray.toJSONString());
            file.flush();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving messages: " + e.getMessage());
        }
    }
}