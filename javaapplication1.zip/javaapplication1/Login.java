/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author thaso
 */
public class Login {
    // Method to check username format
    public static boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Method to check password complexity
    public static boolean checkPasswordComplexity(String password) {
        return password.length() == 8
                && password.matches(".*[A-Z].*")      // At least one capital letter
                && password.matches(".*[0-9].*")      // At least one number
                && password.matches(".*[!@#$%^&*(),.?\":{}|<>].*"); // At least one special character
    }
    
    public static boolean checkPhoneNumber(String phoneNumber) {
        String countryCodePattern = "\\+27\\d{9}";
        return phoneNumber.matches(countryCodePattern);
    }
    
    public static void main(String[] args) {      
        Scanner myInput= new Scanner(System.in);
        String username, password;

        // Username input   
        while (true) {
            System.out.print("Enter a username (must contain '_' and be no more than 5 characters long): ");
            username = myInput.nextLine();
            if (checkUserName(username)) {
                System.out.println("Username successfully captured");
                break;
            } else {
                System.out.println("Username is not correctly formatted. Please ensure it contains an underscore and is no more than 5 characters long.");
            }
        }

        // Last name input
        System.out.print("Please enter your last name: ");
        String userLast = myInput.nextLine();

        // Password input
        while (true) {
            System.out.print("Enter a password (must be 8 characters, contain a capital letter, number and a special character): ");
            password = myInput.nextLine();
            if (checkPasswordComplexity(password)) {
                System.out.println("Password successfully captured");
                break;
            } else {
                System.out.println("Password is not correctly formatted. It must be 8 characters long and contain a capital letter, a number, and a special character.");
            }
        }
        
        // Phone number input
        while (true) {
            System.out.print("Enter your cell phone number (e.g., +27012345678): ");
            String phoneNumber = myInput.nextLine();

            if (checkPhoneNumber(phoneNumber)) {
            System.out.println("Cell phone number successfully added.");
                break;
            } else {
            System.out.println("Cell phone number incorrectly formatted. Please ensure it contains the country code +27 and is followed by 9 digits.");
            }
        }
    }
}
