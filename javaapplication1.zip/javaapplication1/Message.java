/*
 * Enhanced Message class with recipient and timestamp support
 */
package javaapplication1;

/**
 *
 * @author thaso
 */
public class Message {
    private String text;
    private String id;
    private String hash;
    private String recipient;
    private String timestamp;
    
    // Constructor
    public Message(String text, String id, String hash) {
        this.text = text;
        this.id = id;
        this.hash = hash;
    }
    
    // Getter and setter methods
    public String getText() {
        return text;
    }
    
    public void setText(String text) {
        this.text = text;
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getHash() {
        return hash;
    }
    
    public void setHash(String hash) {
        this.hash = hash;
    }
    
    public String getRecipient() {
        return recipient;
    }
    
    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }
    
    public String getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
    
    @Override
    public String toString() {
        return "Message{" +
                "text='" + text + '\'' +
                ", id='" + id + '\'' +
                ", hash='" + hash + '\'' +
                ", recipient='" + recipient + '\'' +
                ", timestamp='" + timestamp + '\'' +
                '}';
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Message message = (Message) obj;
        return id.equals(message.id);
    }
    
    @Override
    public int hashCode() {
        return id.hashCode();
    }
}