/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author thaso
 */


public class Message {
    
    // Private fields
    private String text;
    private String id;
    private String hash;
    private String timestamp;
    private String phoneNumber;
    private String status;
    
    // Default constructor
    public Message() {
        this.text = "";
        this.id = "";
        this.hash = "";
        this.timestamp = "";
        this.phoneNumber = "";
        this.status = "Draft";
    }
    
    // Constructor with basic parameters (used in ChatApp)
    public Message(String text, String id, String hash) {
        this.text = text;
        this.id = id;
        this.hash = hash;
        this.timestamp = "";
        this.phoneNumber = "";
        this.status = "Created";
    }
    
    // Constructor with all parameters
    public Message(String text, String id, String hash, String timestamp, String phoneNumber, String status) {
        this.text = text;
        this.id = id;
        this.hash = hash;
        this.timestamp = timestamp;
        this.phoneNumber = phoneNumber;
        this.status = status;
    }
    
    // Getters
    public String getText() {
        return text;
    }
    
    public String getId() {
        return id;
    }
    
    public String getHash() {
        return hash;
    }
    
    public String getTimestamp() {
        return timestamp;
    }
    
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    public String getStatus() {
        return status;
    }
    
    // Setters
    public void setText(String text) {
        this.text = text;
        // Regenerate hash when text changes if ID exists
        if (this.id != null && !this.id.isEmpty()) {
            this.hash = generateHash(this.id, this.text);
        }
    }
    
    public void setId(String id) {
        this.id = id;
        // Regenerate hash when ID changes if text exists
        if (this.text != null && !this.text.isEmpty()) {
            this.hash = generateHash(this.id, this.text);
        }
    }
    
    public void setHash(String hash) {
        this.hash = hash;
    }
    
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
    
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    // Utility methods that link to ChatApp functionality
    
    /**
     * Generates a random ID using the same logic as ChatApp
     * @return randomly generated 10-digit ID
     */
    public String generateRandomId() {
        java.util.Random rand = new java.util.Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        this.id = id.toString();
        return this.id;
    }
    
    /**
     * Generates message hash using the same logic as ChatApp
     * @param id the message ID
     * @param text the message text
     * @return generated hash
     */
    public String generateHash(String id, String text) {
        if (id == null || id.length() < 2 || text == null || text.trim().isEmpty()) {
            return "";
        }
        
        String[] words = text.trim().split("\\s+");
        String firstTwoDigits = id.substring(0, 2);
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        this.hash = firstTwoDigits + ":0:" + (firstWord + lastWord).toUpperCase();
        return this.hash;
    }
    
    /**
     * Validates message text (same rules as ChatApp)
     * @return true if message is valid, false otherwise
     */
    public boolean isValidMessage() {
        return this.text != null && 
               !this.text.trim().isEmpty() && 
               this.text.length() <= 250;
    }
    
    /**
     * Generates a timestamp for when the message was created
     */
    public void generateTimestamp() {
        java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("HH:mm");
        this.timestamp = formatter.format(new java.util.Date());
    }
    
    /**
     * Generates a random South African phone number (same logic as ChatApp)
     */
    public void generateRandomPhoneNumber() {
        java.util.Random rand = new java.util.Random();
        this.phoneNumber = "0" +
            (80 + rand.nextInt(10)) + " " + 
            (100 + rand.nextInt(900)) + " " + 
            (1000 + rand.nextInt(9000));
    }
    
    /**
     * Creates a complete message with all fields populated
     * @param messageText the text content of the message
     * @return fully populated Message object
     */
    public static Message createCompleteMessage(String messageText) {
        Message msg = new Message();
        msg.setText(messageText);
        msg.generateRandomId();
        msg.generateHash(msg.getId(), msg.getText());
        msg.generateTimestamp();
        msg.generateRandomPhoneNumber();
        msg.setStatus("Ready");
        return msg;
    }
    
    // Override toString for easy display
    @Override
    public String toString() {
        return "Message{" +
                "text='" + text + '\'' +
                ", id='" + id + '\'' +
                ", hash='" + hash + '\'' +
                ", timestamp='" + timestamp + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
    
    // Override equals for comparison
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Message message = (Message) obj;
        return java.util.Objects.equals(id, message.id) &&
               java.util.Objects.equals(hash, message.hash);
    }
    
    // Override hashCode
    @Override
    public int hashCode() {
        return java.util.Objects.hash(id, hash);
    }
}

