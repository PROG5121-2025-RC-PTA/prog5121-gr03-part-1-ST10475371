/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 * Methods class that integrates with ChatApp.java functionality
 * @author thaso
 */
public class Methods {
    
    // Static lists to maintain message state (shared with ChatApp)
    private static List<Message> sentMessages = new ArrayList<>();
    private static List<Message> storedMessages = new ArrayList<>();
    
    /**
     * 1. Creates and returns the message hash using ChatApp's logic
     * This method works with ChatApp's generateMessageHash() method
     * @param messageId the message ID
     * @param messageText the message text
     * @return the generated hash string
     */
    public static String generateMessageHash(String messageId, String messageText) {
        if (messageId == null || messageId.length() < 2 || messageText == null || messageText.trim().isEmpty()) {
            return "";
        }
        
        String[] words = messageText.trim().split("\\s+");
        String firstTwoDigits = messageId.substring(0, 2);
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        return firstTwoDigits + ":0:" + (firstWord + lastWord).toUpperCase();
    }
    
    /**
     * 2. Handles message actions (send, store, discard) - integrates with ChatApp's choice system
     * This method works with ChatApp's message processing logic
     * @param messageText the message to process
     * @param messageId the message ID
     * @param hash the message hash
     * @return status string indicating what action was taken
     */
    public static String processMessageAction(String messageText, String messageId, String hash) {
        String[] options = {"Send Message", "Discard Message", "Store Message to Send Later"};
        int choice = JOptionPane.showOptionDialog(null, 
            "What would you like to do with this message?\nMessage: " + messageText,
            "Choose Action", 
            JOptionPane.DEFAULT_OPTION, 
            JOptionPane.INFORMATION_MESSAGE,
            null, options, options[0]);
        
        switch (choice) {
            case 0: // Send
                sendMessage(messageText, messageId, hash);
                sentMessages.add(new Message(messageText, messageId, hash));
                return "Message sent successfully";
                
            case 1: // Discard
                return "Message discarded";
                
            case 2: // Store
                storedMessages.add(new Message(messageText, messageId, hash));
                storeMessagesToJson(storedMessages);
                return "Message stored for later";
                
            default:
                return "Action cancelled";
        }
    }
    
    /**
     * 3. Returns a formatted list of all sent messages - works with ChatApp's sentMessages
     * This method integrates with ChatApp's message tracking
     * @return formatted string of all sent messages
     */
    public static String getSentMessagesList() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent yet.";
        }
        
        StringBuilder messageList = new StringBuilder();
        messageList.append("=== SENT MESSAGES ===\n");
        messageList.append("Total Messages: ").append(sentMessages.size()).append("\n\n");
        
        for (int i = 0; i < sentMessages.size(); i++) {
            Message msg = sentMessages.get(i);
            messageList.append("Message ").append(i + 1).append(":\n");
            messageList.append("  Text: ").append(msg.getText()).append("\n");
            messageList.append("  ID: ").append(msg.getId()).append("\n");
            messageList.append("  Hash: ").append(msg.getHash()).append("\n");
            messageList.append("  Status: Sent ✔\n");
            messageList.append("-------------------\n");
        }
        
        return messageList.toString();
    }
    
    /**
     * 4. Returns the total number of sent messages - integrates with ChatApp's tracking
     * This method works with ChatApp's message counting
     * @return integer count of total sent messages
     */
    public static int getTotalSentMessages() {
        return sentMessages.size();
    }
    
    /**
     * 5. Custom method to store messages in JSON format - works with ChatApp's JSON storage
     * This method integrates with ChatApp's saveMessagesToJson() method
     * @param messagesToStore list of messages to store
     * @return status string indicating success or failure
     */
    public static String storeMessagesToJson(List<Message> messagesToStore) {
        if (messagesToStore == null || messagesToStore.isEmpty()) {
            return "No messages to store";
        }
        
        try {
            JSONArray jsonArray = new JSONArray();

            for (Message msg : messagesToStore) {
                JSONObject obj = new JSONObject();
                obj.put("text", msg.getText());
                obj.put("id", msg.getId());
                obj.put("hash", msg.getHash());
                obj.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
                obj.put("status", "Stored");
                jsonArray.add(obj);
            }

            try (FileWriter file = new FileWriter("storedMessages.json")) {
                file.write(jsonArray.toJSONString());
                file.flush();
                return "Successfully stored " + messagesToStore.size() + " messages to JSON file";
            }
            
        } catch (IOException e) {
            return "Error storing messages: " + e.getMessage();
        }
    }
    
    // Helper method that integrates with ChatApp's sendMessage functionality
    private static void sendMessage(String messageText, String messageId, String hash) {
        // Ask user to enter recipient's phone number
        String phoneNumber = "";
        while (phoneNumber.isEmpty()) {
            phoneNumber = JOptionPane.showInputDialog(null, "Enter recipient's phone number:");
            if (phoneNumber == null) {
                JOptionPane.showMessageDialog(null, "Message sending cancelled.");
                return;
            }
            phoneNumber = phoneNumber.trim();
            if (phoneNumber.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Phone number cannot be empty. Please enter a valid phone number.");
            }
        }
        String timestamp = new SimpleDateFormat("HH:mm").format(new Date());
        
        JOptionPane.showMessageDialog(null,
            "Sent to: " + phoneNumber +
            "\nTime: " + timestamp +
            "\nMessage: " + messageText +
            "\nStatus: ✔ Sent"
        );

        // Show delivery status (same as ChatApp)
        new Thread(() -> {
            try {
                Thread.sleep(500);
                javax.swing.SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(null, "✔✔ Delivered");
                });
                Thread.sleep(1000);
                javax.swing.SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(null, "<html><font color='blue'>✔✔ Read</font></html>");
                });
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    // Additional helper methods for integration
    
    /**
     * Generates random ID using ChatApp's logic
     * @return 10-digit random ID string
     */
    public static String generateRandomId() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }
    
    /**
     * Gets all stored messages
     * @return list of stored messages
     */
    public static List<Message> getStoredMessages() {
        return new ArrayList<>(storedMessages);
    }
    
    /**
     * Gets all sent messages
     * @return list of sent messages
     */
    public static List<Message> getSentMessages() {
        return new ArrayList<>(sentMessages);
    }
    
    /**
     * Clears all message lists (useful for testing)
     */
    public static void clearAllMessages() {
        sentMessages.clear();
        storedMessages.clear();
    }
    
    /**
     * Returns total count of all messages (sent + stored)
     * @return total message count
     */
    public static int getTotalAllMessages() {
        return sentMessages.size() + storedMessages.size();
    }
    
    /**
     * Display method that shows message statistics
     * @return formatted statistics string
     */
    public static String getMessageStatistics() {
        return "=== MESSAGE STATISTICS ===\n" +
               "Sent Messages: " + sentMessages.size() + "\n" +
               "Stored Messages: " + storedMessages.size() + "\n" +
               "Total Messages: " + getTotalAllMessages();
    }
}